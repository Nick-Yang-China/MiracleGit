/**
 * Walking and comparing directory/file trees (of commits, file system).
 */
package org.eclipse.jgit.treewalk;
