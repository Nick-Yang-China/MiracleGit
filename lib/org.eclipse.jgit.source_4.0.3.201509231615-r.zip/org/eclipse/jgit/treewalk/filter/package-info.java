/**
 * Filters for use in tree walking.
 */
package org.eclipse.jgit.treewalk.filter;
