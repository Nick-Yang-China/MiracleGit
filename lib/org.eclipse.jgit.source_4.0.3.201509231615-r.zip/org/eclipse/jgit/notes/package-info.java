/**
 * Git notes processing (for commits, etc).
 */
package org.eclipse.jgit.notes;
