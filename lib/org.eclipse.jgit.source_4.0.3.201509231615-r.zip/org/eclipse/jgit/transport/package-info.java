/**
 * Transport (fetch/push) for different protocols.
 */
package org.eclipse.jgit.transport;
