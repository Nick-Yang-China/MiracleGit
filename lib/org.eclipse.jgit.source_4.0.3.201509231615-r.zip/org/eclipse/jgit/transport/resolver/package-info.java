/**
 * Server-side resolver for locating repositories by URLs.
 */
package org.eclipse.jgit.transport.resolver;
