/**
 * Ignore rule parser/matcher (for .gitignore entries).
 */
package org.eclipse.jgit.ignore;
