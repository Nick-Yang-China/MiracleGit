/**
 * Utility classes.
 */
package org.eclipse.jgit.util;
