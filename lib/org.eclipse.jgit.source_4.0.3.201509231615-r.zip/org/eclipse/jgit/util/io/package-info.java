/**
 * Utility classes for IO (streams).
 */
package org.eclipse.jgit.util.io;
