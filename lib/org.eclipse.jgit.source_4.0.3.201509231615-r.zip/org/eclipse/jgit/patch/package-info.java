/**
 * Patch file parser and data structure.
 */
package org.eclipse.jgit.patch;
